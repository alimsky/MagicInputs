pref("extensions.magicinputsfiller.boolpref", false);
pref("extensions.magicinputsfiller.intpref", 0);
pref("extensions.magicinputsfiller.stringpref", "A string");

// https://developer.mozilla.org/en/Localizing_extension_descriptions
pref("extensions.magicinputfiller@alimsky.ru.description", "chrome://magicinputsfiller/locale/overlay.properties");
